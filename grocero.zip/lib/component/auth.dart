import 'dart:core';

import 'package:flutter/cupertino.dart';
import 'package:grocero/dao/user_dao.dart';
import 'package:grocero/main.dart';
import 'package:grocero/model/user_model.dart';

class Auth {
  static bool isAuth(){
    return GroceroApp.sharedApp.currentUser != null;
  }

  static int userID(){
    if (isAuth()){
      return GroceroApp.sharedApp.currentUser.id;
    }
    return -1;
  }

  static void logout(){
    GroceroApp.sharedApp.currentUser = null;
  }

  static Future<bool> login(String email, String pass) async {
    var user = await UserDAO.searchByEmail(email);
    if (user != null && user.password == pass) {
      GroceroApp.sharedApp.currentUser = user;
      return true;
    }
    return false;
  }



}